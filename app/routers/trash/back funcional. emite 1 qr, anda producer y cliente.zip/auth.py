import os
from typing import Any, Dict, Optional

import httpx
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(tags=["auth"])


class GoogleLoginIn(BaseModel):
    credential: str  # id_token from Google Identity Services


def _google_client_id() -> str:
    return (os.getenv("VITE_GOOGLE_CLIENT_ID") or os.getenv("GOOGLE_CLIENT_ID") or "").strip()


@router.post("/google")
async def google_login(payload: GoogleLoginIn, request: Request):
    """
    Login real (Google) usando Google Identity Services (id_token).

    Valida el token contra tokeninfo y crea una sesión.
    """
    client_id = _google_client_id()
    if not client_id:
        raise HTTPException(status_code=500, detail="missing_google_client_id")

    token = (payload.credential or "").strip()
    if not token:
        raise HTTPException(status_code=400, detail="missing_credential")

    # tokeninfo valida firma y devuelve claims (depende de disponibilidad de Google).
    # Para producción, se recomienda verificar JWT localmente con librería + cache de keys.
    url = "https://oauth2.googleapis.com/tokeninfo"
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, params={"id_token": token})
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"google_unreachable: {e}")

    if r.status_code != 200:
        raise HTTPException(status_code=401, detail="invalid_token")

    data: Dict[str, Any] = r.json()

    aud = str(data.get("aud") or "")
    if aud != client_id:
        raise HTTPException(status_code=401, detail="invalid_audience")

    sub = str(data.get("sub") or "")
    if not sub:
        raise HTTPException(status_code=401, detail="missing_sub")

    user = {
        "provider": "google",
        "sub": sub,
        "email": data.get("email"),
        "email_verified": str(data.get("email_verified") or "").lower() in ("true", "1", "yes"),
        "meaningful_name": data.get("name") or data.get("given_name") or data.get("email") or "User",
        "name": data.get("name") or data.get("given_name") or data.get("email") or "User",
        "picture": data.get("picture"),
    }

    request.session["user"] = user
    return {"ok": True, "user": user}


@router.post("/logout")
def logout(request: Request):
    request.session.pop("user", None)
    return {"ok": True}
