# main.py
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from app.settings import SESSION_SECRET
from app.routers import producer, public, orders
from app.routers.auth import router as auth_router
import os
from app.routers.public import router as public_router

# APIs primero
app = FastAPI(title="TicketPro API")
app.include_router(auth_router, prefix="/api/auth")
app.include_router(producer.router, prefix="/api/producer")
app.include_router(public.router, prefix="/api/public")
app.include_router(orders.router, prefix="/api/orders")
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET)


# Montar build SPA al final (root)
if os.path.exists("static/index.html"):
    app.mount("/", StaticFiles(directory="static", html=True), name="spa")
