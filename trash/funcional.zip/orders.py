from __future__ import annotations
from typing import List
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from app.db import get_conn
import uuid
from datetime import datetime

router = APIRouter()

class OrderCreate(BaseModel):
    event_slug: str
    sale_item_id: int
    quantity: int = 1



@router.post("/create")
def create_order(payload: OrderCreate, request: Request):
    user = request.session.get("user")
    if not user or not user.get("sub"):
        raise HTTPException(status_code=401, detail="login_required")

    user_id = user["sub"]
    
    with get_conn() as conn:
        cur = conn.cursor()
        
        try:
            # 1. Bloqueo de fila para evitar sobreventa (Race Conditions)
            cur.execute("""
                SELECT price_cents, stock_total, stock_sold, tenant, name
                FROM sale_items 
                WHERE id = %s AND event_slug = %s AND active = True
                FOR UPDATE
            """, (payload.sale_item_id, payload.event_slug))
            
            item = cur.fetchone()
            if not item:
                raise HTTPException(status_code=404, detail="Item no disponible")
            
            price_cents, stock_total, stock_sold, tenant, item_name = item
            
            if (stock_sold + payload.quantity) > stock_total:
                raise HTTPException(status_code=400, detail="No hay stock suficiente")
            
            # 2. Registrar la Orden
            order_id = str(uuid.uuid4())
            total_cents = price_cents * payload.quantity
            
            cur.execute("""
                INSERT INTO orders (id, tenant, event_slug, user_id, total_cents, status, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (order_id, tenant, payload.event_slug, user_id, total_cents, 'paid', datetime.now()))
            
            # 3. Actualizar stock
            cur.execute("""
                UPDATE sale_items 
                SET stock_sold = stock_sold + %s 
                WHERE id = %s
            """, (payload.quantity, payload.sale_item_id))
            
            # 4. Generar el Ticket (Entrada)
            qr_token = str(uuid.uuid4())
            cur.execute("""
                INSERT INTO issued_tickets (tenant, event_slug, order_id, sale_item_id, qr_token, status, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (tenant, payload.event_slug, order_id, payload.sale_item_id, qr_token, 'valid', datetime.now()))
            
            conn.commit()
            return {
                "ok": True, 
                "order_id": order_id, 
                "qr_token": qr_token,
                "event": payload.event_slug,
                "item": item_name
            }
            
        except Exception as e:
            conn.rollback()
            if isinstance(e, HTTPException): raise e
            raise HTTPException(status_code=500, detail=str(e))